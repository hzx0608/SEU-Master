function yy=chazhi(x,y,xx)
% 用例
% x=[0,1,2,3,4,5,6,7,8,9,10];
%y=[2.51,3.30,4.04,4.70,5.22,5.54,5.78,5.40,5.57,5.70,5.80];
% xx=[0.5:1:9.5];
% yy=cubic_spline(x,y,xx)
%Input  - x  已知数据的x坐标
%       - y  已知数据的y坐标
%       - xx 预测位置数据
%Output - yy 三次样条插值输出结果
%第一型，已知两端点处f(x)的1阶导数
f1(1)=0.8; f1(2)=0.2;
n=length(x); h=[];
for i=1:n-1
    h(i)=x(i+1)-x(i);
end
f=[];
for i=1:n-1
    f(i)=(y(i+1)-y(i))/h(i);
end
miu=[];
for i=1:n-2
    miu(i)=h(i)/(h(i)+h(i+1));
end
d=[];
for i=0:n-1
    if i==0
        d(i+1)=(f(i+1)-f1(1))/(h(i+1));
    elseif i==n-1
        d(i+1)=(f1(2)-f(i))/(h(i));
    else
        d(i+1)=(f(i+1)-f(i))/(h(i)+h(i+1));
    end
end
A=[];
for i=1:n
    A(i,i)=2;
    if i==1
        A(i,i+1)=1;
    elseif i==n
        A(i,i-1)=1;
    else
        A(i,i+1)=1-miu(i-1);
        A(i,i-1)=miu(i-1);
    end
end
B=6.*d';
M=A\B;  %求解M向量
 
%构造最后的插值分段函数
s2=[];
for i=1:n-1
    s2(i)=f(i)-(1/3*M(i)+1/6*M(i+1))*h(i);
end
s3=[];
for i=1:n-1
    s3(i)=1/2*M(i);
end
s4=[];
for i=1:n-1
    s4(i)=1/6/h(i)*(M(i+1)-M(i));
end
S=[y(1:n-1)',s2',s3',s4'];
a=x;
digits(5) 
for i=1:n-1
    syms x
    l1(x)=S(i,2)*(x-a(i));
    l2(x)=S(i,3)*(x-a(i))^2;
    l3(x)=S(i,4)*(x-a(i))^3;
    fprintf("-------------------------------------\n")
    Sx(x)=S(i,1)+l1+l2+l3;
    Sx(x)=vpa(Sx);
    fprintf('S(x)=%s \t x∈(%d,%d)\n',char(Sx),i-1,i);
end
fprintf("\n\n\n")
yy=[];
for i=1:length(xx)
    sec=xx(i)-a;
    for j=1:length(sec)
        if sec(j)<0
            flag=j-1;
            break
        end
    end
    yy(i)=S(flag,1)+S(flag,2)*(xx(i)-a(flag))+S(flag,3)*(xx(i)-a(flag))^2+S(flag,4)*(xx(i)-a(flag))^3;
end
end
