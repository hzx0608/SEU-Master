function[result] = chongjifen(a,b,c,d,F,epsilon)
    %% 初值条件
    T0=[];  % 存放Tm,n(f)
    T1=[];  % 存放T(1)m,n(f)
    T2=[];  % 存放T(2)m,n(f)
    T3=[];  % 存放T(3)m,n(f)

    m=1;  % 将[a,b] m等分
    n=1;  % 将[c,d] n等分; 注：虽然这里m与n相等，但分开计算。
    h=(b-a)/m;  % x的步长
    k=(d-c)/n;  % y的步长
    xx=[a,b];
    yy=[c,d];
    e=1; % 误差

    %% 计数位
    count=0;
    T0_count=0;
    T1_count=0;
    T2_count=0;
    T3_count=0;

    %% 计算
    digits(10)
    T=h*k/4*(F(xx(1),yy(1))+F(xx(1),yy(2))+F(xx(2),yy(1))+F(xx(2),yy(2)));
    T0=[T0,T];
    T0_count=T0_count+1;
    count=1;
    fprintf('k=%d,2^k=%d,T0=%0.8f\n',count,2^count,T) 

    while(e>epsilon)
        m=2*m;
        n=2*n;
        h=(b-a)/m;
        k=(d-c)/n;

        % 计算x、y的取值
        xx=[a];  % 暂时只存入左边值
        yy=[c];  % 暂时只存入左边值
        for i=1:m
            temp=a+i*h;
            xx=[xx,temp];
        end
        for j=1:n
            temp =c+j *k;
            yy=[yy,temp];
        end

        % 计算T0
        T=0;
        for i=1:m
            for j=1:n
                T=T+vpa(h*k/4*(F(xx(i),yy(j))+F(xx(i),yy(j+1))+F(xx(i+1),yy(j))+F(xx(i+1),yy(j+1))));
            end
        end
        T0=[T0,T];
        T0_count=T0_count+1;
        count=count+1;
        fprintf('k=%d,2^k=%d,T0=%0.8f',count,2^count,T) 

        % 计算T1
        if T0_count-T1_count==2&&T0_count>= 2
            temp=4/3*T0(end)-1/3*T0(end-1);
            T1=[T1,temp];
            T1_count=T1_count+1;
            fprintf(',T1=%0.8f',T1(end)) 
        end

        % 计算T2
        if T1_count-T2_count==2&&T1_count>=2
            temp=4/3*T1(end)-1/3*T1(end-1);
            T2=[T2,temp];
            T2_count=T2_count+1;
            fprintf(',T2=%0.8f',T2(end)) 
        end

        % 计算T3
        if T2_count-T3_count==2&&T2_count>=2
            temp=4/3*T2(end)-1/3*T2(end-1);
            T3=[T3,temp];
            T3_count=T3_count+1;
            fprintf(',T3=%0.8f',T3(end)) 
        end

        if T3_count>=2
            e=T3(end)-T3(end-1);
            fprintf(', e=%0.8f',e) 
        end
        fprintf('\n') 
    end
    fprintf('复化梯形二重积分求积公式的结果为：%0.8f\n',T3(end))
    result = T3(end);
end